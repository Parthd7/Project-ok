# Ecommerce-version--1

Getting Started with Create React App

This project was bootstrapped with Create React App.
`npm modules`
You can run the command npm inistall to install all the dependies in this project.
Available Scripts

##In the project directory, you can run:
npm start

## About this project

##Ecommerce-V1 
Languages Used--- ReactJS, Nodejs with expres framework , MongoDB DataBase.

modules Used---  JWT,react-use-cart,multer,sharp,razorpay.


Stay in Touch for the new Version...
With Next And Nest as framework for frontend and Backend.
